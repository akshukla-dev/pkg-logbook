<?php
/**
 * @package LMI/LogManager/LogBook/LogMoniter
 * @copyright Copyright (c)2020 Amit Kumar Shukla. All Rights Reserved.
 * @license GNU General Public License version 3, or later
 * @contact akshukla.dev@gmail.com
 */
defined('_JEXEC') or die;

use Joomla\Registry\Registry;

JTable::addIncludePath(JPATH_COMPONENT_ADMINISTRATOR.'/tables');

/**
 * Logmoniter Component Model for a Watchdog record.
 *
 * @since  1.5
 */
class LogmoniterModelWatchdog extends JModelItem
{
    /**
     * Model context string.
     *
     * @var string
     */
    protected $_context = 'com_logmoniter.watchdog';

    /**
     * Method to auto-populate the model state.
     *
     * Note. Calling getState in this method will result in recursion.
     *
     *
     * @since   1.6
     */
    protected function populateState()
    {
        $app = JFactory::getApplication('site');

        // Load the object state.
        $pk = $app->input->getInt('id');
        $this->setState('watchdog.id', $pk);

        // Load the parameters.
        $params = $app->getParams();
        $this->setState('params', $params);

        $user = JFactory::getUser();

        if ((!$user->authorise('core.edit.state', 'com_logmoniter')) && (!$user->authorise('core.edit', 'com_logmoniter'))) {
            $this->setState('filter.published', 1);
            $this->setState('filter.archived', 2);
        }

        $this->setState('filter.language', JLanguageMultilang::isEnabled());
    }

    /**
     * Method to get an object.
     *
     * @param int $id the id of the object to get
     *
     * @return mixed object on success, false on failure
     */
    public function getItem($pk = null)
    {
        $user = JFactory::getUser();

        $pk = (!empty($pk)) ? $pk : (int) $this->getState('watchdog.id');

        if ($this->_item === null) {
            $this->_item = array();
        }

        if (!isset($this->_item[$pk])) {
            try {
                $db = $this->getDbo();
                $query = $db->getQuery(true)
                    ->select($this->getState('item.select', 'wd.*'))
                    ->from('#__logbook_watchdogs AS wd')
                    ->where('wd.id = '.(int) $pk);

                // Join on category table.
                $query->select('c.title AS category_title, c.alias AS category_alias, c.access AS category_access')
                    ->innerJoin('#__categories AS c on c.id = wd.catid')
                    ->where('c.published > 0');

                // Join over the work-centers.
                $query->select('wc.title AS wcenter_title')
                    ->join('LEFT', '#__logbook_workcenters AS wc ON wc.id = wd.wcid');

                // Join over the instrcution sets.
                $query->select('inset.title AS inset_title')
                    ->join('LEFT', '#__logbook_instructionsets AS inset ON inset.id = wd.isid');

                // Join over the Blueprints.
                $query->select('bp.title AS bprint_title')
                    ->join('LEFT', '#__logbook_blueprints AS bp ON bp.id = wd.bpid');

                // Join over the Time Intervals.
                $query->select('ti.title AS tinterval_title')
                    ->join('LEFT', '#__logbook_timeintervals AS ti ON ti.id = wd.tiid');

                // Join on user table.
                $query->select('u.name AS author')
                    ->join('LEFT', '#__users AS u on u.id = wd.created_by');

                // Filter by language
                if ($this->getState('filter.language')) {
                    $query->where('wd.language in ('.$db->quote(JFactory::getLanguage()->getTag()).','.$db->quote('*').')');
                }

                // Join over the categories to get parent category titles
                $query->select('parent.title as parent_title, parent.id as parent_id, parent.path as parent_route, parent.alias as parent_alias')
                    ->join('LEFT', '#__categories as parent ON parent.id = c.parent_id');

                if ((!$user->authorise('core.edit.state', 'com_logmoniter')) && (!$user->authorise('core.edit', 'com_logmoniter'))) {
                    // Filter by start and end dates.
                    $nullDate = $db->quote($db->getNullDate());
                    $date = JFactory::getDate();

                    $nowDate = $db->quote($date->toSql());

                    $query->where('(wd.publish_up = '.$nullDate.' OR wd.publish_up <= '.$nowDate.')')
                        ->where('(wd.publish_down = '.$nullDate.' OR wd.publish_down >= '.$nowDate.')');
                }

                // Filter by published state.
                $published = $this->getState('filter.published');
                $archived = $this->getState('filter.archived');

                if (is_numeric($published)) {
                    $query->where('(wd.state = '.(int) $published.' OR wd.state ='.(int) $archived.')');
                }

                $db->setQuery($query);

                $data = $db->loadObject();

                if (empty($data)) {
                    JError::raiseError(404, JText::_('COM_LOGMONITER_ERROR_WATCHDOG_NOT_FOUND'));
                }

                // Check for published state if filter set.
                if ((is_numeric($published) || is_numeric($archived)) && (($data->state != $published) && ($data->state != $archived))) {
                    JError::raiseError(404, JText::_('COM_LOGMONITER_ERROR_WATCHDOG_NOT_FOUND'));
                }

                // Convert parameter fields to objects.
                $data->params = new Registry($data->params);
                $data->metadata = new Registry($data->metadata);

                // Compute access permissions.
                if ($access = $this->getState('filter.access')) {
                    // If the access filter has been set, we already know this user can view.
                    $data->params->set('access-view', true);
                } else {
                    // If no access filter is set, the layout takes some responsibility for display of limited information.
                    $groups = $user->getAuthorisedViewLevels();
                    $data->params->set('access-view', in_array($data->access, $groups) && in_array($data->category_access, $groups));
                }

                $this->_item[$pk] = $data;
            } catch (Exception $e) {
                $this->setError($e);
                $this->_item[$pk] = false;
            }
        }

        return $this->_item[$pk];
    }

    /**
     * Returns a reference to the a Table object, always creating it.
     *
     * @param string $type   The table type to instantiate
     * @param string $prefix A prefix for the table class name. Optional.
     * @param array  $config Configuration array for model. Optional.
     *
     * @return JTable A database object
     *
     * @since   1.6
     */
    public function getTable($type = 'Watchdog', $prefix = 'LogmoniterTable', $config = array())
    {
        return JTable::getInstance($type, $prefix, $config);
    }

    /**
     * Method to increment the hit counter for the watchdog.
     *
     * @param int $id optional ID of the watchdog
     *
     * @return bool True on success
     */
    public function hit($pk = null)
    {
        if (empty($pk)) {
            $pk = $this->getState('watchdog.id');
        }

        return $this->getTable('Watchdog', 'LogmoniterTable')->hit($pk);
    }
}
