DROP TABLE IF EXISTS `#__logbook_watchdogs`;
